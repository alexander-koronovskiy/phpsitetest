<?php

class News
{
	public static function getNewsItemById($id){
		
	}
	
	public static function getNewsList(){
		
	}
	
}