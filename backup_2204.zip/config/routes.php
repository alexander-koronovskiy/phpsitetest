<?php
//правила соответствия между запросом и методом

return array(
	//'news/([0-9]+)' => 'news/view',
	'news/([a-z]+)/([0-9]+)' => 'news/view/$1/$2',
	
	
	
	'news' => 'news/index', //передача actionIndex в newscontroller
	
	
	
	
	'product' => 'product/list', //передача actionList в productController
);

?>