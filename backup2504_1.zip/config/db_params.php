<?php

return array(
		'host' => 'localhost',
		'dbname' => 'mvc_site',
		'user' => 'root',
		'password' => '',
	);