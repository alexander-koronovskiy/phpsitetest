<?php
/*regular expressions examples

//проверка на наличие шаблона с помощью функции preg_match

$string = 'appples and oranges 9 ';
$pattern= '/[0-9]+/';
$result = preg_match($pattern, $string);
var_dump($result); 


//замена шаблона

//format date dd-mm-yyyy
$string = '21-11-2015';

//new format yyyy-mm-dd
$pattern = '/([0-9]{2})-([0-9]{2})-([0-9]{4})/'; //описание строки с помощью шаблона
$replacement = 'Mounth: $2, Day: $1, Year: $3'; 

//функция замены одного шаюлона на другой
echo preg_replace($pattern, $replacement, $string);
echo '<br>';

*/

// Font controller

//1.общие настройки
ini_set('display_errors',1);
error_reporting(E_ALL);

//2.подключение файлов системы
// показ ошибок
define('ROOT', dirname(__FILE__));
require_once(ROOT.'/components/Router.php');
require_once(ROOT.'/components/Db.php');

//3.установление соединения

//4.вызов router
$router = new Router();
$router -> run(); //передача управления методу

?>