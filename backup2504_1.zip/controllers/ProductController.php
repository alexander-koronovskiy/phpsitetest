<?php

class ProductController
{
	public function actionList(){
		
		echo 'ProductController actionList';
		return true;
	}
}